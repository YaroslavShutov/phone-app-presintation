arStr = window.location.search

btn_eng = document.getElementsByClassName("eng")
btn_ru = document.getElementsByClassName("ru")

title = document.getElementById("title")
subtitle = document.getElementById("subtitle")
created = document.getElementById("created")


texts = {
  eng:{title: "New PhoneApp on your android",
  subtitle: "This PhoneApp collect more info on your phone. You Android can more with this app!",
  created:"Created by Yaroslav Shutov" },
  ru:{title: "Новое приложение для твоего андроида",
  subtitle: "Это приложение собирает больше информации для твоего телефона. Твой агдроид может больше с этим приложением!",
  created:"Создано Чрославом Шутовым"}
}

if(arStr=="?ru"){
  ru()
}
else{
  eng()
}

function eng(){
  title.textContent = texts.eng.title 
  subtitle.textContent = texts.eng.subtitle
  created.textContent = texts.eng.created
}

function ru(){
  title.textContent = texts.ru.title 
  subtitle.textContent = texts.ru.subtitle
  created.textContent = texts.ru.created
}



